export const GET_CATEGORY = "GET_CATEGORY";
export const GET_ERRORS = "GET_ERRORS";
export const DELETE_CATEGORY = "DELETE_CATEGORY";
export const CATEGORY = "CATEGORY";
export const UPDATE_CATEGORY = "UPDATE_CATEGORY";
